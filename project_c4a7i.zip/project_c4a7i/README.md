# Criminal Record Management System

This application will keep a record of all the criminals and their details like name, date of birth, gender, crime, 
reward, etc. also providing them the ability to add new criminals. This app will be used by the police, government,
private security agencies, detectives, and other authorities that are looking for the information. 
This project interests to me because I am willing to do something good for the community. The number of crimes
happening is increasing each day, and we must look into it. For the same reason, I wanted to make an app that could help
control all that.

In the context of criminal record management system application:
- As a user, I want to be able to view the existing records
- As a user, I want to be able to add new criminal records
- As a user, I want to be able to update the crime/offence for an existing criminal
- As a user, I want to be able to change the reward on a criminal
- As a user, I want to be able to view how many criminals are there
- As a user, I want to be able to save the new and updated criminal records
- As a user, I want to be able to load the existing criminal records created earlier

Phase 4: Task 2
- Used HashMap in GUI class in the ui package. 
  
Phase 4: Task 3
- If I had more time to work on the project, I would have used the hashmap in the entire project by refactoring each 
  and every class that may require it. Another change I would make is increasing abstraction of the classes to 
  improve the functionality of the program.